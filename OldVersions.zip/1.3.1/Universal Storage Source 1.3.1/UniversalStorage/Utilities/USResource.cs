﻿

namespace UniversalStorage2
{
	public class USResource
	{
		public string name;
		public double amount;
		public double maxAmount;
	}
}
