﻿
namespace UniversalStorage2
{
    public class USModuleStructuralNode : ModuleStructuralNode, IActivateOnDecouple
    {          
        new public void DecoupleAction(string s, bool b)
        {

        }
    }
}
