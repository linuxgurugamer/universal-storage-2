﻿

namespace UniversalStorage
{
	public class USResource
	{
		public string name;
		public double amount;
		public double maxAmount;
	}
}
